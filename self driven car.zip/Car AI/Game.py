import pygame as pg
from Sprites import *
import neat
from neat import *

pg.init()
screen=pg.display.set_mode()
map=pg.transform.scale(pg.image.load('map.png'),(800,500))
gen=0
font=pg.font.Font(None,30)
time=0
clock=pg.time.Clock()

def drawData(pList):
    for elem in pList:
        elem.update()
        elem.draw()
   
def evalGenome(genomes,config):
    global gen,time
    playerList=[]
    nets = []
    ge = []
                
    for genome_id, genome in genomes:
        genome.fitness = 0  # start with fitness level of 0
        net = neat.nn.FeedForwardNetwork.create(genome, config)
        nets.append(net)
        ge.append(genome)
        playerList.append((Player()))
    run=True
    
    sense = font.render(str('Generations ')+str(gen),1,'black') 
    gen += 1   
    while run and len(playerList) > 0:
        screen.fill('black')
        time+=0.5
        dist=font.render(str('Distance Covered ')+str(int(7*time)),1,'black')  
        for x, player in enumerate(playerList):
            ge[x].fitness += 0.1
            output = nets[playerList.index(player)].activate((player.feedSensors()))
            if output[0] >0.5:
                player.rot += 7
            else:
                player.rot -= 7
                             
        for player in playerList:
            if player.playerCrash():
                ge[playerList.index(player)].fitness -= 3
                nets.pop(playerList.index(player))
                ge.pop(playerList.index(player))
                playerList.pop(playerList.index(player))                
        if len(playerList) == 0:
            time = 0
                
        alive= font.render(str('Alive ')+str(len(playerList)),1,'black')                                            
        screen.blit(map,(0,0))
        screen.blit(sense,(10,10))
        screen.blit(alive,(10,30))
        screen.blit(dist,(10,50))
                                                        
        drawData(playerList)
        clock.tick(899990)
        pg.display.flip() 
            
def run(config_file):
    config = neat.config.Config(neat.DefaultGenome, neat.DefaultReproduction,
                         neat.DefaultSpeciesSet, neat.DefaultStagnation,
                         config_file)
 
    p = neat.Population(config)
 
    p.add_reporter(neat.StdOutReporter(True))
    stats = neat.StatisticsReporter()
    p.add_reporter(stats)
 
    winner = p.run(evalGenome, 500)
    print('\nBest genome:\n{!s}'.format(winner))


if __name__ == '__main__':
    local_dir = os.path.dirname(__file__)
    config_path = os.path.join(local_dir, 'config-feedforward.txt')
    run(config_path)