import pygame as pg
import math
from math import hypot as hyp
from Game import screen,map

vec=pg.math.Vector2

size=[50, 50]
# player class
class Player(pg.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.surface = pg.image.load("car.png")
        self.surface = pg.transform.scale(self.surface, (size[0],size[1]))
        self.pos=[335,405]
        self.rotSurface=self.surface
        self.center=[self.pos[0]+(0.5*50), self.pos[1]+(0.5*50)]
        self.rect=self.surface.get_rect()
        self.vel = vec(0,0)
        self.rot = 0
        self.speed = 8
        self.radars=[]
        self.collide=[]
        self.drawSensors=False
              
    def draw(self):
        screen.blit(self.rotSurface,self.pos)
        if self.drawSensors:
            self.drawRadar()
        
    def update(self):
        self.rotSurface=self.rotPlayer(self.surface,self.rot)
        self.center=[self.pos[0]+(0.5*size[0]), self.pos[1]+(0.5*size[1])]
        self.radars.clear()
        self.runRadar()
        self.vel = vec(self.speed, 0).rotate(-self.rot)
        self.pos+=self.vel
        
        self.edges()
        
    def edges(self):
        len=25
        
        leftTop = [self.center[0] + math.cos(math.radians(360 - (self.rot + 30))) * len, self.center[1] + math.sin(math.radians(360 - (self.rot + 30))) * len]
        rightTop = [self.center[0] + math.cos(math.radians(360 - (self.rot + 150))) * len, self.center[1] + math.sin(math.radians(360 - (self.rot + 150))) * len]
        leftBottom = [self.center[0] + math.cos(math.radians(360 - (self.rot + 210))) * len, self.center[1] + math.sin(math.radians(360 - (self.rot + 210))) * len]
        rightBottom = [self.center[0] + math.cos(math.radians(360 - (self.rot + 330))) * len, self.center[1] + math.sin(math.radians(360 - (self.rot + 330))) * len]

        self.fourPoints = [leftTop, rightTop, leftBottom, rightBottom]
        return self.fourPoints
                       
    def drawRadar(self):
        for r in self.radars:
            pos,dist = r
            pg.draw.line(screen, 'green' ,self.center, pos, 1)
            pg.draw.circle(screen, 'black' , pos, 4)

    def checkRadar(self, degree):
        len = 0
        x = int(self.center[0] + math.cos(math.radians(360 - (self.rot + degree))) * len)
        y = int(self.center[1] + math.sin(math.radians(360 - (self.rot + degree))) * len)     

        while len < 500 and not map.get_at((x,y)) == (255,255,255):
            len = len + 1
            x = int(self.center[0] + math.cos(math.radians(360 - (self.rot + degree))) * len)
            y = int(self.center[1] + math.sin(math.radians(360 - (self.rot + degree))) * len)
            
        dist = int(math.sqrt(math.pow(x - self.center[0], 2) + math.pow(y - self.center[1], 2)))
        self.radars.append([[x, y],len])
               
    def runRadar(self):
        for d in range(-90, 120, 45):
            self.checkRadar(d)
            
    def feedSensors(self):
        radars = self.radars
        ret = [0 for i in range(5)]   
        for i, r in enumerate(radars):
            ret[i] = int(r[1])
        return ret
                                       
    def rotPlayer(self,image,angle):
        origRect = image.get_rect()
        rotImage = pg.transform.rotate(image, angle)
        rotRect = origRect.copy()
        rotRect.center = rotImage.get_rect().center
        rotImage = rotImage.subsurface(rotRect).copy()
        return rotImage
        

    def playerCrash(self):
        for p in self.edges():      
            if map.get_at((int(p[0]), int(p[1]))) == (255,255,255,255):
                return True
        return False
    
        
            
 

        
        